import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl,FormBuilder, Validators
} from "@angular/forms";
import { debounceTime } from "rxjs/operators";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  searchField: FormControl;
  searches:string[]=[];

  userForm = new FormGroup({
    name: new FormControl('any data', [Validators.required, Validators.minLength(4), Validators.maxLength(10)]),
    email: new FormControl('my@getMaxListeners.com'),

    address:new FormGroup({
      street: new FormControl(),
      city: new FormControl(),
      postalcode: new FormControl(45, Validators.pattern('^[2-9][0-9]{4}$'))
    })
  });
  ngOnInit(){
    this.searchField=new FormControl();
    this.searchField.valueChanges.pipe(
      debounceTime(2000)
      
      )
      .subscribe(term => {
        console.log(term);
        this.searches.push(term);
      });
  }
  onSubmit(){
    console.log(this.userForm.value);
  }


}
